const soundList = {
    'coin':'src/sound/soundBank/coin.mp3',
    'environment':'src/sound/soundBank/retreat.mp3',
    'win':'src/sound/soundBank/win.mp3'
}
export default soundList