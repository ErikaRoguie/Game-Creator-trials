const fileList = {
    "0":"idle.fbx",
    "1":"jump.fbx",
    "2":"left strafe walk.fbx",
    "3":"left strafe.fbx",
    "4":"left turn.fbx",
    "5":"right strafe walk.fbx",
    "6":"right strafe.fbx",
    "7":"right turn.fbx",
    "8":"running.fbx",
    "9":"walking.fbx"
}
export default fileList