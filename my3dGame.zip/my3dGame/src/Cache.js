let cache = document.createElement('div')

export default cache