const scene = new THREE.Scene();

export default scene